// يمكن تعبئة القيم آلياً بعد ربط مشروع Supabase.
// مفتاح anon/publishable آمن للاستخدام داخل تطبيق العميل مع تفعيل RLS.
window.SEKRETARY_CLOUD = window.SEKRETARY_CLOUD || {
  url: "",
  anonKey: ""
};
