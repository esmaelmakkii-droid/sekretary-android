package com.sekretary.app;
import android.app.*;import android.content.*;import android.os.Build;import java.util.*;
public class DailyMessageReceiver extends BroadcastReceiver{
 static final String PREF="daily_messages";
 static final String[] MORNING={
 "صباح القوة يا عبير 🌤️، يوم جديد وفرصة جديدة. خديها خطوة خطوة — إسماعيل",
 "صباح النشاط يا عبير ✨، أهم حاجة تبدأي؛ الباقي بيتظبط معاك — إسماعيل",
 "صباح جميل يا عبير 💛، ركزي على أهم مهمة وادي يومك بداية قوية — إسماعيل",
 "صباح الإنجاز يا عبير ☀️، رتبي يومك على مزاجك وابدئي بالحاجة البتفرق — إسماعيل",
 "صباح هادي وقوي يا عبير 🌿، خطوة مركزة هسي أحسن من تأجيل كتير — إسماعيل",
 "صباحك خفيف يا عبير ✨، جدولك موجود عشان يساعدك ما عشان يضغطك — إسماعيل"
};
 static final String[] EVENING={
 "مساء هادئ يا عبير 🌙، شوفي الباقي بهدوء وسيبي لبكرة البستاهل — إسماعيل",
 "مساء الإنجاز يا عبير ✨، أي خطوة عملتيها اليوم محسوبة ليك — إسماعيل",
 "تصبحي على خير يا عبير 🌙، راجعي بكرة بسرعة وارتاحي كويس — إسماعيل",
 "مساءك مرتب يا عبير 💛، اقفلي اليوم بالمهم وخلي بكرة يبدأ واضح — إسماعيل",
 "مساء هادي يا عبير 🌿، ما تنسي تشوفي أول حاجة عندك بكرة وبعدها ريحي بالك — إسماعيل",
 "ليلة طيبة يا عبير ✨، كل حاجة ما خلصت اليوم ممكن تتخطط صح لبكرة — إسماعيل"
};
 @Override public void onReceive(Context c,Intent i){boolean m=i.getBooleanExtra("morning",true);String[] a=m?MORNING:EVENING;String msg=a[(int)(System.currentTimeMillis()/86400000L)%a.length];NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel("sekretary_daily","رسائل سكرتيري اليومية",NotificationManager.IMPORTANCE_DEFAULT));Intent open=new Intent(c,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(c,m?701:702,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,"sekretary_daily"):new Notification.Builder(c);b.setSmallIcon(R.drawable.app_icon).setContentTitle(m?"رسالة الصباح من إسماعيل ☀️":"رسالة المساء من إسماعيل 🌙").setContentText(msg).setStyle(new Notification.BigTextStyle().bigText(msg)).setAutoCancel(true).setContentIntent(pi);try{nm.notify(m?701:702,b.build());}catch(SecurityException ignored){}}
 public static void ensureDefaults(Context c){if(!c.getSharedPreferences(PREF,0).getBoolean("set",false))schedule(c,"07:30","21:30");}
 public static void schedule(Context c,String morning,String evening){c.getSharedPreferences(PREF,0).edit().putBoolean("set",true).putString("morning",morning).putString("evening",evening).apply();set(c,morning,true,701);set(c,evening,false,702);}
 public static void restore(Context c){android.content.SharedPreferences p=c.getSharedPreferences(PREF,0);schedule(c,p.getString("morning","07:30"),p.getString("evening","21:30"));}
 static void set(Context c,String t,boolean morning,int code){try{String[]x=t.split(":");Calendar cal=Calendar.getInstance();cal.set(Calendar.HOUR_OF_DAY,Integer.parseInt(x[0]));cal.set(Calendar.MINUTE,Integer.parseInt(x[1]));cal.set(Calendar.SECOND,0);if(cal.getTimeInMillis()<=System.currentTimeMillis())cal.add(Calendar.DAY_OF_YEAR,1);Intent i=new Intent(c,DailyMessageReceiver.class).putExtra("morning",morning);PendingIntent pi=PendingIntent.getBroadcast(c,code,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).setInexactRepeating(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);}catch(Exception ignored){}}
}
