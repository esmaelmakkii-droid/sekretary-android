package com.sekretary.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONObject;

public final class Scheduler {
    private static final String PREFS = "sekretary_native_reminders";
    private Scheduler() {}

    public static void schedule(Context context, String id, String title, long triggerAt, String repeat, boolean persist) {
        if (triggerAt <= System.currentTimeMillis()) return;
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.putExtra("id", id);
        intent.putExtra("title", title);
        intent.putExtra("triggerAt", triggerAt);
        intent.putExtra("repeat", repeat == null ? "none" : repeat);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, id.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        } else {
            alarm.set(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        }
        if (persist) save(context, id, title, triggerAt, repeat);
    }

    public static void cancel(Context context, String id) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, ReminderReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, id.hashCode(), intent,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pi != null) {
            alarm.cancel(pi);
            pi.cancel();
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove("r_" + id).apply();
    }

    static void save(Context context, String id, String title, long triggerAt, String repeat) {
        try {
            JSONObject o = new JSONObject();
            o.put("id", id);
            o.put("title", title);
            o.put("triggerAt", triggerAt);
            o.put("repeat", repeat == null ? "none" : repeat);
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().putString("r_" + id, o.toString()).apply();
        } catch (Exception ignored) {}
    }

    static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static long nextTrigger(long from, String repeat) {
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.setTimeInMillis(from);
        if ("daily".equals(repeat)) c.add(java.util.Calendar.DAY_OF_YEAR, 1);
        else if ("weekly".equals(repeat)) c.add(java.util.Calendar.WEEK_OF_YEAR, 1);
        else if ("monthly".equals(repeat)) c.add(java.util.Calendar.MONTH, 1);
        else if ("yearly".equals(repeat)) c.add(java.util.Calendar.YEAR, 1);
        else return -1L;
        return c.getTimeInMillis();
    }
}
