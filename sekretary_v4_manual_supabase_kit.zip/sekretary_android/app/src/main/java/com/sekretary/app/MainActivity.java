package com.sekretary.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.drawable.Icon;
import android.graphics.Color;
import android.view.View;
import android.os.*;
import android.speech.RecognizerIntent;
import android.webkit.*;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int REQ_SPEECH=44, REQ_NOTIFICATIONS=45, REQ_LOCATION=46;
    private WebView webView; private boolean quickVoice=false; private boolean pageReady=false;
    @Override protected void onCreate(Bundle b){super.onCreate(b);createChannel();quickVoice=getIntent().getBooleanExtra("quick_voice",false);webView=new WebView(this);setContentView(webView);WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);s.setGeolocationEnabled(true);s.setAllowFileAccess(true);webView.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView v,String u){pageReady=true;if(quickVoice){quickVoice=false;startVoiceRecognition(true);}}});webView.setWebChromeClient(new WebChromeClient(){@Override public void onGeolocationPermissionsShowPrompt(String o,GeolocationPermissions.Callback c){boolean ok=checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED||checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;c.invoke(o,ok,false);if(!ok&&Build.VERSION.SDK_INT>=23)requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION},REQ_LOCATION);}});webView.addJavascriptInterface(new AndroidBridge(),"AndroidBridge");webView.loadUrl("file:///android_asset/index.html");installDynamicShortcut();DailyMessageReceiver.ensureDefaults(this);}
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);if(i.getBooleanExtra("quick_voice",false)){if(pageReady)startVoiceRecognition(true);else quickVoice=true;}}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("sekretary_reminders","تذكيرات سكرتيري",NotificationManager.IMPORTANCE_HIGH);getSystemService(NotificationManager.class).createNotificationChannel(c);}}
    private void installDynamicShortcut(){if(Build.VERSION.SDK_INT>=25){ShortcutManager sm=getSystemService(ShortcutManager.class);Intent i=new Intent(this,MainActivity.class).setAction(Intent.ACTION_VIEW).putExtra("quick_voice",true);ShortcutInfo sh=new ShortcutInfo.Builder(this,"voice_add").setShortLabel("موعد بالصوت").setLongLabel("إضافة موعد بالصوت").setIcon(Icon.createWithResource(this,R.drawable.app_icon)).setIntent(i).build();sm.setDynamicShortcuts(Collections.singletonList(sh));}}
    private void startVoiceRecognition(boolean quick){quickVoice=quick;Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ar-SD");i.putExtra(RecognizerIntent.EXTRA_PROMPT,"اتكلمي يا عبير…");try{startActivityForResult(i,REQ_SPEECH);}catch(Exception e){showJsStatus("التعرف الصوتي غير متوفر على الجهاز.");}}
    public class AndroidBridge{
        @JavascriptInterface public void scheduleReminder(String j){try{JSONObject t=new JSONObject(j);String id=t.getString("id"),title=t.optString("title","عندك تذكير"),date=t.optString("date",""),time=t.optString("time",""),repeat=t.optString("repeat","none");int before=t.optInt("remindBefore",0);if(date.isEmpty()||time.isEmpty())return;Date due=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).parse(date+" "+time);if(due!=null)Scheduler.schedule(MainActivity.this,id,title,due.getTime()-before*60000L,repeat,true);}catch(Exception ignored){}}
        @JavascriptInterface public void cancelReminder(String id){Scheduler.cancel(MainActivity.this,id);}
        @JavascriptInterface public void requestNotifications(){runOnUiThread(()->{if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFICATIONS);else showJsStatus("تم تفعيل الإشعارات ✅");});}
        @JavascriptInterface public void startVoice(){runOnUiThread(()->startVoiceRecognition(false));}
        @JavascriptInterface public void pinVoiceShortcut(){runOnUiThread(()->{if(Build.VERSION.SDK_INT>=26){ShortcutManager sm=getSystemService(ShortcutManager.class);if(sm.isRequestPinShortcutSupported()){Intent i=new Intent(MainActivity.this,MainActivity.class).setAction(Intent.ACTION_VIEW).putExtra("quick_voice",true);ShortcutInfo sh=new ShortcutInfo.Builder(MainActivity.this,"voice_add_pin").setShortLabel("موعد بالصوت").setIcon(Icon.createWithResource(MainActivity.this,R.drawable.app_icon)).setIntent(i).build();sm.requestPinShortcut(sh,null);showJsStatus("اختاري إضافة الاختصار للشاشة الرئيسية ✅");}}});}
        @JavascriptInterface public void setDailyMessages(String morning,String evening){DailyMessageReceiver.schedule(MainActivity.this,morning,evening);showJsStatus("تم ضبط رسائل الصباح والمساء ✅");}
        @JavascriptInterface public void setSystemDark(boolean dark){runOnUiThread(()->{getWindow().setStatusBarColor(Color.parseColor(dark?"#0E1017":"#F4F5FB"));getWindow().setNavigationBarColor(Color.parseColor(dark?"#171A24":"#FFFFFF"));if(Build.VERSION.SDK_INT>=23){int flags=getWindow().getDecorView().getSystemUiVisibility();if(dark)flags&=~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;else flags|=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;getWindow().getDecorView().setSystemUiVisibility(flags);}});}
        @JavascriptInterface public void requestLocation(){runOnUiThread(()->{if(Build.VERSION.SDK_INT>=23)requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION},REQ_LOCATION);});}
    }
    private void showJsStatus(String t){if(webView!=null)webView.evaluateJavascript("document.getElementById('permissionStatus').textContent="+JSONObject.quote(t),null);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==REQ_SPEECH&&c==RESULT_OK&&d!=null){ArrayList<String>x=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(x!=null&&!x.isEmpty()){boolean q=quickVoice;quickVoice=false;webView.evaluateJavascript("nativeVoiceResult("+JSONObject.quote(x.get(0))+","+q+")",null);}}}
    @Override public void onRequestPermissionsResult(int r,String[]p,int[]g){super.onRequestPermissionsResult(r,p,g);boolean ok=g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED;if(r==REQ_NOTIFICATIONS)showJsStatus(ok?"تم تفعيل الإشعارات ✅":"لم يتم السماح بالإشعارات.");if(r==REQ_LOCATION)showJsStatus(ok?"تم السماح بالموقع ✅":"لم يتم السماح بالموقع.");}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
