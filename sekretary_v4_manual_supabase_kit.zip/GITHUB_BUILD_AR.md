# بناء APK من GitHub — من الموبايل

## 1) ارفع المشروع

افتح مستودعك `sekretary-android` على GitHub.

ارفع **محتويات مجلد `sekretary_android` نفسه** إلى جذر المستودع، بحيث يظهر عندك مباشرة:

- `app/`
- `.github/`
- `build.gradle`
- `settings.gradle`
- `supabase_schema.sql`

لا ترفع مجلد `sekretary_android` كطبقة إضافية إذا كنت ستستخدم Workflow الموجود داخله.

## 2) شغل البناء

افتح تبويب `Actions`.

اختار `Build Sekretary APK`.

لو ما بدأ تلقائياً:

- اضغط `Run workflow`
- اختار `main`
- اضغط `Run workflow`

## 3) تنزيل APK

بعد ظهور علامة ✅ خضراء:

- افتح آخر Run.
- انزل إلى `Artifacts`.
- نزّل `sekretary-debug-apk`.
- فك الضغط.
- ثبّت `app-debug.apk`.

## ملاحظة

نسخة Debug للتجربة. بعد ما نثبت إن كل شيء شغال نعمل Release موقعة للتوزيع.
