-- فحص سريع بعد تشغيل 01_schema.sql

select table_name
from information_schema.tables
where table_schema='public'
  and table_name in ('profiles','couples','couple_members','couple_permissions','couple_invites','tasks')
order by table_name;

select tablename, rowsecurity
from pg_tables
where schemaname='public'
  and tablename in ('profiles','couples','couple_members','couple_permissions','couple_invites','tasks')
order by tablename;

select schemaname, tablename, policyname, cmd
from pg_policies
where schemaname='public'
order by tablename, policyname;
