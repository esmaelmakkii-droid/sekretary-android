# سكرتيري V4 — دليل الربط اليدوي مع Supabase

هذا الباكج معمول عشان تشتغل يدوي خطوة خطوة بدون ما نعتمد على أي أداة خارجية.

## الموجود داخل الباكج

- `sekretary_android/` مشروع Android كامل.
- `supabase/01_schema.sql` قاعدة البيانات + الصلاحيات + ربط الحسابين.
- `supabase/02_verify.sql` فحص سريع للتأكد إن الجداول وRLS اتعملوا صح.
- `SUPABASE_VALUES_HERE.txt` مكان تحفظ فيه Project URL والمفتاح publishable مؤقتاً عندك.
- `GITHUB_BUILD_AR.md` طريقة رفع المشروع وبناء APK من GitHub Actions.
- `TEST_PLAN_AR.md` اختبار إسماعيل + عبير بعد الربط.

## الخطوات المختصرة

1. اعمل مشروع Supabase جديد باسم `Sekretary`.
2. افتح SQL Editor وشغّل محتوى `supabase/01_schema.sql` مرة واحدة.
3. شغّل `supabase/02_verify.sql` وتأكد إن كل الجداول فيها RLS = true.
4. من Project Settings > API انسخ:
   - Project URL
   - Publishable key أو anon key
5. افتح التطبيق > حول/الإعدادات > Supabase Sync، وحط الرابط والمفتاح.
6. اعمل حساب عبير في جهاز، وحساب إسماعيل في الجهاز الثاني.
7. من صفحة المشاركة: واحد يعمل كود ربط، والثاني يدخل الكود.
8. كل طرف يحدد بنفسه هل يسمح للطرف الآخر يشوف جدوله الخاص.
9. أي موعد فئة `مشترك` يظهر للطرفين بعد المزامنة.

> مهم: لا تستخدم `service_role` داخل التطبيق نهائياً. استخدم publishable/anon فقط.
