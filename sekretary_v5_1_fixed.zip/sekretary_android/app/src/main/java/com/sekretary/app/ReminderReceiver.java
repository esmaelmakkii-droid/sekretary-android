package com.sekretary.app;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String id = intent.getStringExtra("id");
        String title = intent.getStringExtra("title");
        String repeat = intent.getStringExtra("repeat");
        long triggerAt = intent.getLongExtra("triggerAt", System.currentTimeMillis());
        if (id == null) id = String.valueOf(System.currentTimeMillis());
        if (title == null || title.trim().isEmpty()) title = "عندك تذكير";

        NotificationPrefs.createChannels(context, false);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(context, 1000 + id.hashCode(), open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new android.app.Notification.Builder(context, NotificationPrefs.CHANNEL_REMINDERS)
                : new android.app.Notification.Builder(context);
        b.setSmallIcon(R.drawable.app_icon)
         .setContentTitle("سكرتيري 🔔")
         .setContentText(title)
         .setStyle(new android.app.Notification.BigTextStyle().bigText(title + "\nموعدك قرب — افتحي سكرتيري للتفاصيل."))
         .setAutoCancel(true)
         .setContentIntent(content)
         .setPriority(android.app.Notification.PRIORITY_HIGH)
         .setVisibility(android.app.Notification.VISIBILITY_PUBLIC);
        if (Build.VERSION.SDK_INT < 26) {
            b.setSound(NotificationPrefs.getSoundUri(context));
            b.setVibrate(new long[]{0,250,120,250});
        }
        try { nm.notify(id.hashCode(), b.build()); } catch (SecurityException ignored) {}

        long next = Scheduler.nextTrigger(triggerAt, repeat == null ? "none" : repeat);
        if (next > 0) {
            while (next <= System.currentTimeMillis()) {
                long n2 = Scheduler.nextTrigger(next, repeat);
                if (n2 <= next) break;
                next = n2;
            }
            Scheduler.schedule(context, id, title, next, repeat, true);
        } else {
            Scheduler.prefs(context).edit().remove("r_" + id).apply();
        }
    }
}
