package com.sekretary.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

public final class NotificationPrefs {
    private static final String PREF = "sekretary_notification_prefs";
    private static final String KEY_SOUND = "sound_uri";
    private static final String KEY_LABEL = "sound_label";
    public static final String CHANNEL_REMINDERS = "sekretary_reminders_v5";
    public static final String CHANNEL_DAILY = "sekretary_daily_v5";

    private NotificationPrefs() {}

    public static Uri getSoundUri(Context c) {
        String saved = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_SOUND, null);
        if (saved == null || saved.trim().isEmpty()) return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        try { return Uri.parse(saved); } catch (Exception e) { return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION); }
    }

    public static String getSoundLabel(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String label = p.getString(KEY_LABEL, null);
        if (label != null && !label.trim().isEmpty()) return label;
        try {
            Uri u = getSoundUri(c);
            Ringtone r = RingtoneManager.getRingtone(c, u);
            return r == null ? "النغمة الافتراضية" : r.getTitle(c);
        } catch (Exception e) { return "النغمة الافتراضية"; }
    }

    public static void saveSound(Context c, Uri uri) {
        String label = "النغمة الافتراضية";
        try {
            if (uri != null) {
                Ringtone r = RingtoneManager.getRingtone(c, uri);
                if (r != null) label = r.getTitle(c);
            }
        } catch (Exception ignored) {}
        SharedPreferences.Editor e = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit();
        if (uri == null) e.remove(KEY_SOUND); else e.putString(KEY_SOUND, uri.toString());
        e.putString(KEY_LABEL, label).apply();
        createChannels(c, true);
    }

    public static void createChannels(Context c, boolean forceRecreate) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (forceRecreate) {
            try { nm.deleteNotificationChannel(CHANNEL_REMINDERS); } catch (Exception ignored) {}
            try { nm.deleteNotificationChannel(CHANNEL_DAILY); } catch (Exception ignored) {}
        }
        Uri sound = getSoundUri(c);
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();

        NotificationChannel reminders = new NotificationChannel(
                CHANNEL_REMINDERS, "تذكيرات سكرتيري", NotificationManager.IMPORTANCE_HIGH);
        reminders.setDescription("المواعيد والمهام المهمة");
        reminders.enableVibration(true);
        reminders.setVibrationPattern(new long[]{0, 250, 120, 250});
        reminders.setSound(sound, attrs);
        nm.createNotificationChannel(reminders);

        NotificationChannel daily = new NotificationChannel(
                CHANNEL_DAILY, "رسائل سكرتيري اليومية", NotificationManager.IMPORTANCE_DEFAULT);
        daily.setDescription("رسائل الصباح والمساء");
        daily.enableVibration(true);
        daily.setSound(sound, attrs);
        nm.createNotificationChannel(daily);
    }
}
