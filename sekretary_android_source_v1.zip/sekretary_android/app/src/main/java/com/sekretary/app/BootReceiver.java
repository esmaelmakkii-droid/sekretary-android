package com.sekretary.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.util.Map;
import org.json.JSONObject;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        Map<String, ?> all = Scheduler.prefs(context).getAll();
        for (Object value : all.values()) {
            if (!(value instanceof String)) continue;
            try {
                JSONObject o = new JSONObject((String) value);
                String id = o.getString("id");
                String title = o.optString("title", "عندك تذكير");
                String repeat = o.optString("repeat", "none");
                long trigger = o.getLong("triggerAt");
                if (trigger <= System.currentTimeMillis() && !"none".equals(repeat)) {
                    do { trigger = Scheduler.nextTrigger(trigger, repeat); }
                    while (trigger > 0 && trigger <= System.currentTimeMillis());
                }
                if (trigger > System.currentTimeMillis()) Scheduler.schedule(context, id, title, trigger, repeat, true);
            } catch (Exception ignored) {}
        }
    }
}
