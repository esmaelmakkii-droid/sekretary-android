package com.sekretary.app;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_SPEECH = 44;
    private static final int REQ_NOTIFICATIONS = 45;
    private static final int REQ_LOCATION = 46;
    private WebView webView;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createChannel();
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                boolean fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
                boolean coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
                callback.invoke(origin, fine || coarse, false);
                if (!fine && !coarse && Build.VERSION.SDK_INT >= 23) {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
                }
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("sekretary_reminders", "تذكيرات سكرتيري", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("مواعيد ومهام سكرتيري");
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    public class AndroidBridge {
        @JavascriptInterface public void scheduleReminder(String taskJson) {
            try {
                JSONObject t = new JSONObject(taskJson);
                String id = t.getString("id");
                String title = t.optString("title", "عندك تذكير");
                String date = t.optString("date", "");
                String time = t.optString("time", "");
                int before = t.optInt("remindBefore", 0);
                String repeat = t.optString("repeat", "none");
                if (date.isEmpty() || time.isEmpty()) return;
                SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
                Date due = f.parse(date + " " + time);
                if (due == null) return;
                long trigger = due.getTime() - before * 60000L;
                Scheduler.schedule(MainActivity.this, id, title, trigger, repeat, true);
            } catch (Exception ignored) {}
        }

        @JavascriptInterface public void cancelReminder(String id) {
            Scheduler.cancel(MainActivity.this, id);
        }

        @JavascriptInterface public void requestNotifications() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
                } else {
                    showJsStatus("تم تفعيل الإشعارات ✅");
                }
            });
        }

        @JavascriptInterface public void startVoice() {
            runOnUiThread(() -> {
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SD");
                i.putExtra(RecognizerIntent.EXTRA_PROMPT, "اتكلمي يا عبير…");
                try { startActivityForResult(i, REQ_SPEECH); }
                catch (Exception e) { showJsStatus("التعرف الصوتي غير متوفر على الجهاز."); }
            });
        }

        @JavascriptInterface public void requestLocation() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 23) {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
                }
            });
        }
    }

    private void showJsStatus(String text) {
        if (webView == null) return;
        String q = JSONObject.quote(text);
        webView.evaluateJavascript("document.getElementById('permissionStatus').textContent=" + q, null);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                String q = JSONObject.quote(results.get(0));
                webView.evaluateJavascript("nativeVoiceResult(" + q + ")", null);
            }
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == REQ_NOTIFICATIONS) showJsStatus(ok ? "تم تفعيل الإشعارات ✅" : "لم يتم السماح بالإشعارات.");
        if (requestCode == REQ_LOCATION) showJsStatus(ok ? "تم السماح بالموقع ✅" : "لم يتم السماح بالموقع.");
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
