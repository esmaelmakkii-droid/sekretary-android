package com.sekretary.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ShortcutInfo;
import android.app.ShortcutManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.Icon;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.view.View;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_SPEECH=44;
    private static final int REQ_NOTIFICATIONS=45;
    private static final int REQ_LOCATION=46;
    private static final int REQ_RINGTONE=47;

    private WebView webView;
    private boolean quickVoice=false;
    private boolean pageReady=false;

    @Override protected void onCreate(android.os.Bundle b){
        super.onCreate(b);
        NotificationPrefs.createChannels(this,false);
        quickVoice=getIntent().getBooleanExtra("quick_voice",false);
        webView=new WebView(this);
        setContentView(webView);
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(true);
        webView.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView v,String u){
                pageReady=true;
                sendNativeSettingsStatus();
                if(quickVoice){quickVoice=false;startVoiceRecognition(true);}
            }
        });
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public void onGeolocationPermissionsShowPrompt(String o, GeolocationPermissions.Callback c){
                boolean ok=checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED||checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;
                c.invoke(o,ok,false);
                if(!ok&&Build.VERSION.SDK_INT>=23)requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION},REQ_LOCATION);
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(),"AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
        installDynamicShortcut();
        DailyMessageReceiver.ensureDefaults(this);
        requestNotificationPermissionOnce();
    }

    @Override protected void onResume(){
        super.onResume();
        if(pageReady) sendNativeSettingsStatus();
    }

    @Override protected void onNewIntent(Intent i){
        super.onNewIntent(i);setIntent(i);
        if(i.getBooleanExtra("quick_voice",false)){
            if(pageReady)startVoiceRecognition(true);else quickVoice=true;
        }
    }

    private void requestNotificationPermissionOnce(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            android.content.SharedPreferences p=getSharedPreferences("sekretary_permissions",MODE_PRIVATE);
            if(!p.getBoolean("notification_asked",false)){
                p.edit().putBoolean("notification_asked",true).apply();
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFICATIONS);
            }
        }
    }

    private boolean notificationsAllowed(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return false;
        NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        return Build.VERSION.SDK_INT<24 || nm.areNotificationsEnabled();
    }

    private boolean exactAlarmAllowed(){
        if(Build.VERSION.SDK_INT<31)return true;
        AlarmManager a=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
        return a.canScheduleExactAlarms();
    }

    private void sendNativeSettingsStatus(){
        if(webView==null)return;
        String js="if(window.nativeNotificationStatus)nativeNotificationStatus("+
                JSONObject.quote(NotificationPrefs.getSoundLabel(this))+","+
                notificationsAllowed()+","+exactAlarmAllowed()+")";
        webView.evaluateJavascript(js,null);
    }

    private void installDynamicShortcut(){
        if(Build.VERSION.SDK_INT>=25){
            ShortcutManager sm=getSystemService(ShortcutManager.class);
            Intent i=new Intent(this,MainActivity.class).setAction(Intent.ACTION_VIEW).putExtra("quick_voice",true);
            ShortcutInfo sh=new ShortcutInfo.Builder(this,"voice_add")
                    .setShortLabel("موعد بالصوت")
                    .setLongLabel("إضافة موعد بالصوت")
                    .setIcon(Icon.createWithResource(this,R.drawable.app_icon))
                    .setIntent(i).build();
            sm.setDynamicShortcuts(Collections.singletonList(sh));
        }
    }

    private void startVoiceRecognition(boolean quick){
        quickVoice=quick;
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ar-SD");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT,"اتكلمي يا عبير…");
        try{startActivityForResult(i,REQ_SPEECH);}catch(Exception e){showJsStatus("التعرف الصوتي غير متوفر على الجهاز.");}
    }

    private void pickNotificationSound(){
        Intent i=new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE,RingtoneManager.TYPE_NOTIFICATION);
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE,"اختاري نغمة تنبيهات سكرتيري");
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT,true);
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT,false);
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,NotificationPrefs.getSoundUri(this));
        try{startActivityForResult(i,REQ_RINGTONE);}catch(Exception e){showJsStatus("تعذر فتح نغمات الهاتف.");}
    }

    private void requestExactAlarmAccess(){
        if(Build.VERSION.SDK_INT<31){showJsStatus("التنبيهات الدقيقة مفعلة على جهازك ✅");return;}
        AlarmManager alarm=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
        if(alarm.canScheduleExactAlarms()){showJsStatus("التنبيهات الدقيقة مفعلة ✅");sendNativeSettingsStatus();return;}
        try{
            Intent i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName()));
            startActivity(i);
        }catch(Exception e){showJsStatus("افتحي إعدادات التطبيق وفعلي Alarms & reminders.");}
    }

    public class AndroidBridge{
        @JavascriptInterface public void scheduleReminder(String j){
            try{
                JSONObject t=new JSONObject(j);
                String id=t.getString("id"),title=t.optString("title","عندك تذكير"),date=t.optString("date",""),time=t.optString("time",""),repeat=t.optString("repeat","none");
                int before=t.optInt("remindBefore",0);
                if(date.isEmpty()||time.isEmpty())return;
                Date due=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).parse(date+" "+time);
                if(due!=null)Scheduler.schedule(MainActivity.this,id,title,due.getTime()-before*60000L,repeat,true);
            }catch(Exception ignored){}
        }
        @JavascriptInterface public void cancelReminder(String id){Scheduler.cancel(MainActivity.this,id);}
        @JavascriptInterface public void requestNotifications(){runOnUiThread(()->{
            if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFICATIONS);
            else {showJsStatus("الإشعارات مفعلة ✅");sendNativeSettingsStatus();}
        });}
        @JavascriptInterface public void chooseNotificationSound(){runOnUiThread(()->pickNotificationSound());}
        @JavascriptInterface public void requestExactAlarm(){runOnUiThread(()->requestExactAlarmAccess());}
        @JavascriptInterface public void testNotification(){runOnUiThread(()->{
            if(!notificationsAllowed()){showJsStatus("فعّلي إذن الإشعارات أولاً.");return;}
            Scheduler.schedule(MainActivity.this,"test_"+System.currentTimeMillis(),"تجربة ناجحة 🎉 تنبيهات سكرتيري شغالة",System.currentTimeMillis()+3500L,"none",false);
            showJsStatus("حيصلك تنبيه تجريبي بعد ثواني 🔔");
        });}
        @JavascriptInterface public void startVoice(){runOnUiThread(()->startVoiceRecognition(false));}
        @JavascriptInterface public void pinVoiceShortcut(){runOnUiThread(()->{
            if(Build.VERSION.SDK_INT>=26){
                ShortcutManager sm=getSystemService(ShortcutManager.class);
                if(sm.isRequestPinShortcutSupported()){
                    Intent i=new Intent(MainActivity.this,MainActivity.class).setAction(Intent.ACTION_VIEW).putExtra("quick_voice",true);
                    ShortcutInfo sh=new ShortcutInfo.Builder(MainActivity.this,"voice_add_pin").setShortLabel("موعد بالصوت").setIcon(Icon.createWithResource(MainActivity.this,R.drawable.app_icon)).setIntent(i).build();
                    sm.requestPinShortcut(sh,null);showJsStatus("اختاري إضافة الاختصار للشاشة الرئيسية ✅");
                }
            }
        });}
        @JavascriptInterface public void setDailyMessages(String morning,String evening){DailyMessageReceiver.schedule(MainActivity.this,morning,evening);showJsStatus("تم ضبط رسائل الصباح والمساء ✅");}
        @JavascriptInterface public void setSystemDark(boolean dark){runOnUiThread(()->{
            getWindow().setStatusBarColor(Color.parseColor(dark?"#0E1017":"#F4F5FB"));
            getWindow().setNavigationBarColor(Color.parseColor(dark?"#171A24":"#FFFFFF"));
            if(Build.VERSION.SDK_INT>=23){
                int flags=getWindow().getDecorView().getSystemUiVisibility();
                if(dark)flags&=~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;else flags|=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                getWindow().getDecorView().setSystemUiVisibility(flags);
            }
        });}
        @JavascriptInterface public void requestLocation(){runOnUiThread(()->{if(Build.VERSION.SDK_INT>=23)requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION},REQ_LOCATION);});}
    }

    private void showJsStatus(String t){
        if(webView!=null)webView.evaluateJavascript("if(document.getElementById('permissionStatus'))document.getElementById('permissionStatus').textContent="+JSONObject.quote(t),null);
    }

    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==REQ_RINGTONE){
            if(c==RESULT_OK&&d!=null){
                Uri u=d.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
                NotificationPrefs.saveSound(this,u);
                showJsStatus("تم اختيار النغمة: "+NotificationPrefs.getSoundLabel(this)+" ✅");
                sendNativeSettingsStatus();
            }
            return;
        }
        if(r==REQ_SPEECH&&c==RESULT_OK&&d!=null){
            ArrayList<String>x=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if(x!=null&&!x.isEmpty()){
                boolean q=quickVoice;quickVoice=false;
                webView.evaluateJavascript("nativeVoiceResult("+JSONObject.quote(x.get(0))+","+q+")",null);
            }
        }
    }

    @Override public void onRequestPermissionsResult(int r,String[]p,int[]g){
        super.onRequestPermissionsResult(r,p,g);
        boolean ok=g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED;
        if(r==REQ_NOTIFICATIONS){showJsStatus(ok?"تم تفعيل الإشعارات ✅":"لم يتم السماح بالإشعارات.");sendNativeSettingsStatus();}
        if(r==REQ_LOCATION)showJsStatus(ok?"تم السماح بالموقع ✅":"لم يتم السماح بالموقع.");
    }

    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
