-- Sekretary V4 Manual Setup
-- شغّل هذا الملف مرة واحدة داخل Supabase SQL Editor.
-- لا تضع service_role داخل التطبيق. استخدم فقط Project URL + publishable/anon key.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.couples (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now()
);

create table if not exists public.couple_members (
  couple_id uuid not null references public.couples(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (couple_id, user_id),
  unique (user_id)
);

create table if not exists public.couple_permissions (
  couple_id uuid not null references public.couples(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  viewer_id uuid not null references auth.users(id) on delete cascade,
  can_view_schedule boolean not null default false,
  can_edit_shared boolean not null default true,
  updated_at timestamptz not null default now(),
  primary key (couple_id, owner_id, viewer_id),
  check (owner_id <> viewer_id)
);

create table if not exists public.couple_invites (
  id uuid primary key default gen_random_uuid(),
  couple_id uuid not null references public.couples(id) on delete cascade,
  inviter_id uuid not null references auth.users(id) on delete cascade,
  code text not null unique,
  expires_at timestamptz not null default (now() + interval '24 hours'),
  accepted_by uuid references auth.users(id),
  accepted_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  couple_id uuid references public.couples(id) on delete set null,
  title text not null,
  category text not null default 'شخصي',
  due_at timestamptz not null,
  end_at timestamptz,
  priority text not null default 'normal' check (priority in ('normal','important','urgent')),
  repeat_rule text not null default 'none',
  remind_before integer not null default 0 check (remind_before >= 0),
  location text,
  notes text,
  status text not null default 'open' check (status in ('open','done')),
  is_shared boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists tasks_owner_due_idx on public.tasks(owner_id, due_at);
create index if not exists tasks_couple_due_idx on public.tasks(couple_id, due_at) where couple_id is not null;
create index if not exists couple_members_user_idx on public.couple_members(user_id);
create index if not exists couple_permissions_viewer_idx on public.couple_permissions(viewer_id, owner_id);
create index if not exists couple_invites_code_idx on public.couple_invites(code);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles(id, display_name)
  values(new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email,'@',1)))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_couple_member(p_couple uuid, p_user uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(
    select 1 from public.couple_members
    where couple_id = p_couple and user_id = p_user
  );
$$;

create or replace function public.my_couple_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select couple_id
  from public.couple_members
  where user_id = auth.uid()
  order by joined_at desc
  limit 1;
$$;

create or replace function public.create_couple_invite()
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  c uuid;
  new_code text;
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  select couple_id into c
  from public.couple_members
  where user_id = auth.uid()
  limit 1;

  if c is null then
    insert into public.couples default values returning id into c;
    insert into public.couple_members(couple_id,user_id)
    values(c,auth.uid());
  end if;

  loop
    new_code := upper(substr(md5(random()::text || clock_timestamp()::text),1,6));
    exit when not exists(
      select 1 from public.couple_invites
      where code = new_code
        and expires_at > now()
        and accepted_at is null
    );
  end loop;

  insert into public.couple_invites(couple_id,inviter_id,code)
  values(c,auth.uid(),new_code);

  return new_code;
end;
$$;

create or replace function public.accept_couple_invite(p_code text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  inv public.couple_invites%rowtype;
  c uuid;
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  if exists(select 1 from public.couple_members where user_id = auth.uid()) then
    raise exception 'This account is already linked';
  end if;

  select * into inv
  from public.couple_invites
  where code = upper(trim(p_code))
    and accepted_at is null
    and expires_at > now()
  order by created_at desc
  limit 1;

  if inv.id is null then
    raise exception 'Invite code is invalid or expired';
  end if;

  if inv.inviter_id = auth.uid() then
    raise exception 'Use this code on the other account';
  end if;

  c := inv.couple_id;

  insert into public.couple_members(couple_id,user_id)
  values(c,auth.uid())
  on conflict do nothing;

  insert into public.couple_permissions(couple_id,owner_id,viewer_id,can_view_schedule)
  values
    (c,inv.inviter_id,auth.uid(),false),
    (c,auth.uid(),inv.inviter_id,false)
  on conflict do nothing;

  update public.couple_invites
  set accepted_by = auth.uid(), accepted_at = now()
  where id = inv.id;

  return c;
end;
$$;

create or replace function public.set_schedule_permission(p_allow boolean)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  c uuid;
  partner uuid;
begin
  c := public.my_couple_id();
  if c is null then raise exception 'No linked account'; end if;

  select user_id into partner
  from public.couple_members
  where couple_id = c and user_id <> auth.uid()
  limit 1;

  if partner is null then raise exception 'Partner has not joined yet'; end if;

  insert into public.couple_permissions(couple_id,owner_id,viewer_id,can_view_schedule,updated_at)
  values(c,auth.uid(),partner,p_allow,now())
  on conflict(couple_id,owner_id,viewer_id)
  do update set can_view_schedule = excluded.can_view_schedule, updated_at = now();
end;
$$;

create or replace function public.get_my_couple_context()
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  c uuid;
  p uuid;
  result jsonb;
begin
  c := public.my_couple_id();
  if c is null then return null; end if;

  select user_id into p
  from public.couple_members
  where couple_id = c and user_id <> auth.uid()
  limit 1;

  if p is null then
    return jsonb_build_object(
      'couple_id',c,
      'partner_id',null,
      'partner_name',null,
      'i_allow_partner',false,
      'partner_allows_me',false
    );
  end if;

  select jsonb_build_object(
    'couple_id',c,
    'partner_id',p,
    'partner_name',coalesce((select display_name from public.profiles where id=p),'الطرف الآخر'),
    'i_allow_partner',coalesce((select can_view_schedule from public.couple_permissions where couple_id=c and owner_id=auth.uid() and viewer_id=p),false),
    'partner_allows_me',coalesce((select can_view_schedule from public.couple_permissions where couple_id=c and owner_id=p and viewer_id=auth.uid()),false)
  ) into result;

  return result;
end;
$$;

create or replace function public.touch_task_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists tasks_touch_updated_at on public.tasks;
create trigger tasks_touch_updated_at
before update on public.tasks
for each row execute function public.touch_task_updated_at();

create or replace function public.protect_task_ownership()
returns trigger
language plpgsql
as $$
begin
  if new.owner_id <> old.owner_id then
    raise exception 'owner_id cannot be changed';
  end if;
  return new;
end;
$$;

drop trigger if exists tasks_protect_owner on public.tasks;
create trigger tasks_protect_owner
before update on public.tasks
for each row execute function public.protect_task_ownership();

alter table public.profiles enable row level security;
alter table public.couples enable row level security;
alter table public.couple_members enable row level security;
alter table public.couple_permissions enable row level security;
alter table public.couple_invites enable row level security;
alter table public.tasks enable row level security;

-- Profiles: each user can read own profile. Partner name is fetched safely through RPC.
drop policy if exists profiles_select_own on public.profiles;
create policy profiles_select_own
on public.profiles for select to authenticated
using ((select auth.uid()) = id);

drop policy if exists profiles_update_own on public.profiles;
create policy profiles_update_own
on public.profiles for update to authenticated
using ((select auth.uid()) = id)
with check ((select auth.uid()) = id);

-- Couple membership data is visible only to members of that couple.
drop policy if exists couples_select_members on public.couples;
create policy couples_select_members
on public.couples for select to authenticated
using (public.is_couple_member(id,(select auth.uid())));

drop policy if exists members_select_same_couple on public.couple_members;
create policy members_select_same_couple
on public.couple_members for select to authenticated
using (public.is_couple_member(couple_id,(select auth.uid())));

drop policy if exists permissions_select_members on public.couple_permissions;
create policy permissions_select_members
on public.couple_permissions for select to authenticated
using (public.is_couple_member(couple_id,(select auth.uid())));

drop policy if exists permissions_owner_update on public.couple_permissions;
create policy permissions_owner_update
on public.couple_permissions for update to authenticated
using (owner_id = (select auth.uid()))
with check (owner_id = (select auth.uid()));

drop policy if exists invites_select_inviter on public.couple_invites;
create policy invites_select_inviter
on public.couple_invites for select to authenticated
using (inviter_id = (select auth.uid()));

-- Tasks:
-- 1) owner always sees own task.
-- 2) shared task is visible to both couple members.
-- 3) private partner task is visible only after explicit permission.
drop policy if exists tasks_select_visible on public.tasks;
create policy tasks_select_visible
on public.tasks for select to authenticated
using (
  owner_id = (select auth.uid())
  or (
    couple_id is not null
    and public.is_couple_member(couple_id,(select auth.uid()))
    and (
      is_shared = true
      or exists(
        select 1
        from public.couple_permissions cp
        where cp.couple_id = tasks.couple_id
          and cp.owner_id = tasks.owner_id
          and cp.viewer_id = (select auth.uid())
          and cp.can_view_schedule = true
      )
    )
  )
);

drop policy if exists tasks_insert_own on public.tasks;
create policy tasks_insert_own
on public.tasks for insert to authenticated
with check (
  owner_id = (select auth.uid())
  and (couple_id is null or public.is_couple_member(couple_id,(select auth.uid())))
);

-- Owner can update own tasks. Partner may update only shared tasks in the same couple.
drop policy if exists tasks_update_owner_or_shared on public.tasks;
create policy tasks_update_owner_or_shared
on public.tasks for update to authenticated
using (
  owner_id = (select auth.uid())
  or (
    is_shared = true
    and couple_id is not null
    and public.is_couple_member(couple_id,(select auth.uid()))
  )
)
with check (
  owner_id = (select auth.uid())
  or (
    is_shared = true
    and couple_id is not null
    and public.is_couple_member(couple_id,(select auth.uid()))
  )
);

drop policy if exists tasks_delete_owner on public.tasks;
create policy tasks_delete_owner
on public.tasks for delete to authenticated
using (owner_id = (select auth.uid()));

-- API grants
revoke all on public.profiles,public.couples,public.couple_members,public.couple_permissions,public.couple_invites,public.tasks from anon;
grant usage on schema public to authenticated;
grant select,insert,update,delete on public.profiles,public.tasks to authenticated;
grant select on public.couples,public.couple_members,public.couple_permissions,public.couple_invites to authenticated;

revoke all on function public.create_couple_invite() from public, anon;
revoke all on function public.accept_couple_invite(text) from public, anon;
revoke all on function public.get_my_couple_context() from public, anon;
revoke all on function public.set_schedule_permission(boolean) from public, anon;

grant execute on function public.create_couple_invite() to authenticated;
grant execute on function public.accept_couple_invite(text) to authenticated;
grant execute on function public.get_my_couple_context() to authenticated;
grant execute on function public.set_schedule_permission(boolean) to authenticated;

-- Optional: keep PostgREST schema cache fresh.
notify pgrst, 'reload schema';
