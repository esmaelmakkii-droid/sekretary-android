package com.sekretary.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String id = intent.getStringExtra("id");
        String title = intent.getStringExtra("title");
        String repeat = intent.getStringExtra("repeat");
        long triggerAt = intent.getLongExtra("triggerAt", System.currentTimeMillis());

        if (id == null) id = String.valueOf(System.currentTimeMillis());
        if (title == null || title.trim().isEmpty()) title = "عندك تذكير";
        if (repeat == null) repeat = "none";

        Intent alarm = new Intent(context, AlarmService.class);
        alarm.setAction(AlarmService.ACTION_START);
        alarm.putExtra("id", id);
        alarm.putExtra("title", title);
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(alarm);
        else context.startService(alarm);

        long next = Scheduler.nextTrigger(triggerAt, repeat);
        if (next > 0) {
            while (next <= System.currentTimeMillis()) {
                long n2 = Scheduler.nextTrigger(next, repeat);
                if (n2 <= next) break;
                next = n2;
            }
            Scheduler.schedule(context, id, title, next, repeat, true);
        } else {
            Scheduler.prefs(context).edit().remove("r_" + id).apply();
        }
    }
}
