package com.sekretary.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AlarmActivity extends Activity {
    private String alarmId;
    private String alarmTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            );
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.rgb(67, 56, 202));
        getWindow().setNavigationBarColor(Color.rgb(20, 20, 30));

        alarmId = getIntent().getStringExtra("id");
        alarmTitle = getIntent().getStringExtra("title");
        if (alarmId == null) alarmId = String.valueOf(System.currentTimeMillis());
        if (alarmTitle == null || alarmTitle.trim().isEmpty()) alarmTitle = "عندك موعد";

        setContentView(buildView());
    }

    private View buildView() {
        int pad = dp(24);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(Color.rgb(17, 18, 27));

        TextView brand = new TextView(this);
        brand.setText("سكرتيري ⏰");
        brand.setTextColor(Color.rgb(196, 190, 255));
        brand.setTextSize(22);
        brand.setGravity(Gravity.CENTER);
        brand.setPadding(0, 0, 0, dp(18));
        root.addView(brand, new LinearLayout.LayoutParams(-1, -2));

        TextView time = new TextView(this);
        time.setText(new SimpleDateFormat("hh:mm a", new Locale("ar")).format(new Date()));
        time.setTextColor(Color.WHITE);
        time.setTextSize(54);
        time.setGravity(Gravity.CENTER);
        time.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(time, new LinearLayout.LayoutParams(-1, -2));

        TextView title = new TextView(this);
        title.setText(alarmTitle);
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(22), 0, dp(34));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        Button snooze = new Button(this);
        snooze.setText("غفوة 10 دقائق");
        snooze.setTextSize(18);
        snooze.setAllCaps(false);
        snooze.setOnClickListener(v -> snoozeAlarm());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(58));
        bp.setMargins(0, 0, 0, dp(14));
        root.addView(snooze, bp);

        Button stop = new Button(this);
        stop.setText("إيقاف المنبه");
        stop.setTextSize(19);
        stop.setAllCaps(false);
        stop.setOnClickListener(v -> stopAlarm());
        root.addView(stop, new LinearLayout.LayoutParams(-1, dp(62)));

        TextView hint = new TextView(this);
        hint.setText("المنبه حيستمر لحدي ما توقفيه أو تعملي غفوة");
        hint.setTextColor(Color.rgb(180, 180, 195));
        hint.setTextSize(14);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(24), 0, 0);
        root.addView(hint, new LinearLayout.LayoutParams(-1, -2));

        return root;
    }

    private void stopAlarm() {
        Intent i = new Intent(this, AlarmService.class);
        i.setAction(AlarmService.ACTION_STOP);
        i.putExtra("id", alarmId);
        startService(i);
        finishAndRemoveTask();
    }

    private void snoozeAlarm() {
        Intent i = new Intent(this, AlarmService.class);
        i.setAction(AlarmService.ACTION_SNOOZE);
        i.putExtra("id", alarmId);
        i.putExtra("title", alarmTitle);
        startService(i);
        finishAndRemoveTask();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        stopAlarm();
    }
}
