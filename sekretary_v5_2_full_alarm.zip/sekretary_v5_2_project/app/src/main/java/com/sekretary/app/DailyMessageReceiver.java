package com.sekretary.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import java.util.Calendar;

public class DailyMessageReceiver extends BroadcastReceiver {
    static final String PREF="daily_messages";
    static final String[] MORNING={
            "صباح القوة يا عبير ✨ خدي يومك خطوة خطوة، وأول إنجاز صغير حيغيّر الإيقاع كله.",
            "صباح النشاط يا عبير ☀️ اختاري أهم حاجة وابدئي بيها؛ الباقي بنرتبه بعدين.",
            "صباح جميل يا عبير 💛 يومك ما محتاج يكون مثالي، محتاج بداية بس.",
            "صباح الإنجاز يا عبير 🌿 ركزي على الحاجة البتفرق فعلاً وخلي الباقي يمشي بهدوء.",
            "صباحك طاقة يا عبير ✨ خطوة مركزة هسي أحسن من تأجيل كبير.",
            "صباح الخير يا عبير ☀️ خلي جدولك يساعدك، ما يضغطك؛ واحدة واحدة وبمزاج حلو."
    };
    static final String[] EVENING={
            "مساء هادي يا عبير 🌙 شوفي الحصل اليوم، خدي الجميل منه وسيبي الباقي لبكرة.",
            "مساء الإنجاز يا عبير ✨ أي خطوة عملتيها اليوم محسوبة ليك، حتى لو كانت صغيرة.",
            "ليلة مرتبة يا عبير 💛 راجعي أول حاجة بكرة، وبعدها اقفلي اليوم براحة.",
            "مساء لطيف يا عبير 🌿 خلصي المهم وسيبي مساحة لنفسك ترتاح.",
            "مساءك هادي يا عبير 🌙 بكرة أوضح لما آخر دقيقتين الليلة يكونوا للتخطيط.",
            "تصبحي على خير يا عبير ✨ بكرة فرصة جديدة، والجدول جاهز يستقبلك."
    };

    @Override public void onReceive(Context c, Intent i) {
        boolean morning=i.getBooleanExtra("morning",true);
        String[] a=morning?MORNING:EVENING;
        String msg=a[(int)(System.currentTimeMillis()/86400000L)%a.length];
        NotificationPrefs.createChannels(c, false);
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        Intent open=new Intent(c,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(c,morning?701:702,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26
                ?new Notification.Builder(c,NotificationPrefs.CHANNEL_DAILY)
                :new Notification.Builder(c);
        b.setSmallIcon(R.drawable.app_icon)
         .setContentTitle(morning?"رسالة الصباح من إسماعيل ☀️":"رسالة المساء من إسماعيل 🌙")
         .setContentText(msg)
         .setStyle(new Notification.BigTextStyle().bigText(msg+"\n\n— إسماعيل"))
         .setAutoCancel(true)
         .setContentIntent(pi);
        if(Build.VERSION.SDK_INT<26){b.setSound(android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION));b.setVibrate(new long[]{0,180,100,180});}
        try{nm.notify(morning?701:702,b.build());}catch(SecurityException ignored){}
        SharedPreferences p=c.getSharedPreferences(PREF,0);
        scheduleOne(c,p.getString(morning?"morning":"evening",morning?"07:30":"21:30"),morning,morning?701:702);
    }

    public static void ensureDefaults(Context c){
        if(!c.getSharedPreferences(PREF,0).getBoolean("set",false))schedule(c,"07:30","21:30");
    }

    public static void schedule(Context c,String morning,String evening){
        c.getSharedPreferences(PREF,0).edit().putBoolean("set",true).putString("morning",morning).putString("evening",evening).apply();
        scheduleOne(c,morning,true,701);
        scheduleOne(c,evening,false,702);
    }

    public static void restore(Context c){
        SharedPreferences p=c.getSharedPreferences(PREF,0);
        schedule(c,p.getString("morning","07:30"),p.getString("evening","21:30"));
    }

    static void scheduleOne(Context c,String t,boolean morning,int code){
        try{
            String[]x=t.split(":");
            Calendar cal=Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY,Integer.parseInt(x[0]));
            cal.set(Calendar.MINUTE,Integer.parseInt(x[1]));
            cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);
            if(cal.getTimeInMillis()<=System.currentTimeMillis())cal.add(Calendar.DAY_OF_YEAR,1);
            Intent i=new Intent(c,DailyMessageReceiver.class).putExtra("morning",morning);
            PendingIntent pi=PendingIntent.getBroadcast(c,code,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Scheduler.setAlarm(c,cal.getTimeInMillis(),pi);
        }catch(Exception ignored){}
    }
}
