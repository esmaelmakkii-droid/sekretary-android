package com.sekretary.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

public class AlarmService extends Service {
    public static final String ACTION_START = "com.sekretary.app.action.ALARM_START";
    public static final String ACTION_STOP = "com.sekretary.app.action.ALARM_STOP";
    public static final String ACTION_SNOOZE = "com.sekretary.app.action.ALARM_SNOOZE";
    private static final int NOTIFICATION_ID = 9520;

    private MediaPlayer player;
    private Vibrator vibrator;
    private PowerManager.WakeLock wakeLock;
    private String currentId;
    private String currentTitle;

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationPrefs.createChannels(this, false);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();

        if (ACTION_STOP.equals(action)) {
            stopAlarm();
            stopSelf();
            return START_NOT_STICKY;
        }

        if (ACTION_SNOOZE.equals(action)) {
            String id = intent.getStringExtra("id");
            String title = intent.getStringExtra("title");
            if (id == null) id = currentId == null ? "alarm" : currentId;
            if (title == null || title.trim().isEmpty()) title = currentTitle == null ? "عندك موعد" : currentTitle;
            stopAlarm();
            Scheduler.schedule(this,
                    id + "_snooze_" + System.currentTimeMillis(),
                    title + " — غفوة",
                    System.currentTimeMillis() + 10 * 60_000L,
                    "none",
                    false);
            stopSelf();
            return START_NOT_STICKY;
        }

        currentId = intent.getStringExtra("id");
        currentTitle = intent.getStringExtra("title");
        if (currentId == null) currentId = String.valueOf(System.currentTimeMillis());
        if (currentTitle == null || currentTitle.trim().isEmpty()) currentTitle = "عندك موعد";

        startForeground(NOTIFICATION_ID, buildAlarmNotification(currentId, currentTitle));
        acquireWakeLock();
        startSoundAndVibration();
        return START_NOT_STICKY;
    }

    private Notification buildAlarmNotification(String id, String title) {
        Intent full = new Intent(this, AlarmActivity.class);
        full.putExtra("id", id);
        full.putExtra("title", title);
        full.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent fullPi = PendingIntent.getActivity(
                this,
                6000 + id.hashCode(),
                full,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, AlarmService.class).setAction(ACTION_STOP).putExtra("id", id);
        PendingIntent stopPi = PendingIntent.getService(
                this,
                7000 + id.hashCode(),
                stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent snooze = new Intent(this, AlarmService.class).setAction(ACTION_SNOOZE)
                .putExtra("id", id).putExtra("title", title);
        PendingIntent snoozePi = PendingIntent.getService(
                this,
                8000 + id.hashCode(),
                snooze,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, NotificationPrefs.CHANNEL_ALARM)
                : new Notification.Builder(this);

        b.setSmallIcon(R.drawable.app_icon)
                .setContentTitle("سكرتيري ⏰")
                .setContentText(title)
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setPriority(Notification.PRIORITY_MAX)
                .setOngoing(true)
                .setAutoCancel(false)
                .setFullScreenIntent(fullPi, true)
                .setContentIntent(fullPi)
                .addAction(new Notification.Action.Builder(R.drawable.app_icon, "غفوة 10 د", snoozePi).build())
                .addAction(new Notification.Action.Builder(R.drawable.app_icon, "إيقاف", stopPi).build());

        return b.build();
    }

    private void startSoundAndVibration() {
        stopSoundAndVibration();
        try {
            Uri uri = NotificationPrefs.getSoundUri(this);
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            player.setDataSource(this, uri);
            player.setLooping(true);
            player.prepare();
            player.start();
        } catch (Exception first) {
            try {
                Uri fallback = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM);
                player = new MediaPlayer();
                player.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build());
                player.setDataSource(this, fallback);
                player.setLooping(true);
                player.prepare();
                player.start();
            } catch (Exception ignored) {}
        }

        try {
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            long[] pattern = new long[]{0, 600, 350, 600, 350};
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0));
                else vibrator.vibrate(pattern, 0);
            }
        } catch (Exception ignored) {}
    }

    private void stopSoundAndVibration() {
        try {
            if (player != null) {
                if (player.isPlaying()) player.stop();
                player.release();
                player = null;
            }
        } catch (Exception ignored) {}
        try {
            if (vibrator != null) vibrator.cancel();
        } catch (Exception ignored) {}
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Sekretary:AlarmWakeLock");
            wakeLock.acquire(10 * 60_000L);
        } catch (Exception ignored) {}
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) {}
        wakeLock = null;
    }

    private void stopAlarm() {
        stopSoundAndVibration();
        releaseWakeLock();
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.cancel(NOTIFICATION_ID);
        } catch (Exception ignored) {}
    }

    @Override
    public void onDestroy() {
        stopAlarm();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
